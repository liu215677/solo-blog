title: java 字符串转json ，json转对象，对象转json
date: '2019-06-04 16:22:58'
updated: '2019-06-04 16:22:58'
tags: [java, json]
permalink: /articles/2019/06/04/1559636578782.html
---
# 1、字符串转json
**com.alibaba.fastjson.JSONObject**
```
JSONObject js= new JSONObject().parseObject("{"":"","":""}");
```

# 2、json转对象
```
JSONObject js= new JSONObject().parseObject("{"":"","":""}");
PersonLocusSelView p=js.toJavaObject(PersonLocusSelView.class);
```
# 3、对象转json
PersonLocusSelView 就是对象
```
PersonLocusSelView p=this;
JSONObject js=new JSONObject();
String uStr=js.toJSONString(p);
```
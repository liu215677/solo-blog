title: powerdesigner设置字体大小
date: '2019-06-04 10:46:44'
updated: '2019-06-04 10:56:54'
tags: [建模工具]
permalink: /articles/2019/06/04/1559616404173.html
---
# 1、选择工具=》常规选项
![image.png](https://img.hacpai.com/file/2019/06/image-343349e2.png)
![image.png](https://img.hacpai.com/file/2019/06/image-604f5047.png)
设置对应的大小即可
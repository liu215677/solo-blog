title: 记一次 cnpm install 失效问题
date: '2019-07-08 10:28:29'
updated: '2019-07-08 10:30:04'
tags: [cnpm, vue, nodejs]
permalink: /articles/2019/07/08/1562552909124.html
---
# 1、问题重现
周一来了办公室后启动项目失败，发现是周五把node_modules给删除了，所以执行cnpm install 发现失效，只是光标闪烁，cnpm -v也无反应，百度上查了很多解决方案也不好用，所以打算试试刚开始安装cnpm的方法结果成功了
# 2、解决思路
卸载cnpm
```
npm uninstall cnpm -g
```
安装cnpm
```
npm install -g cnpm --registry=https://registry.npm.taobao.org
```
配置镜像
```
npm config set registry https://registry.npm.taobao.org
```
检查是否成功
```
//查看路径配置是否正确
npm config get registry
//查看cnpm是否安装成功
cnpm -v
```
最后执行 cnpm install
成功！


title: element  el-autocomplete 选择数据后不回显问题
date: '2019-08-14 17:21:34'
updated: '2019-08-14 17:25:05'
tags: [vue, element]
permalink: /articles/2019/08/14/1565774493875.html
---
# 1、问题描述
 之前做的input下拉选择本来是好的，可是做了另一个功能给绑定的值赋值后发现不会回显研究之后才发现是以下问题

````
<el-autocomplete

class="inline-input"

v-model="reqForm.robotSiteName"

:fetch-suggestions="robotQuerySearch"

placeholder="请输入内容"

@select="robotHandleSelect"

>

<template  slot-scope="{ item }">

<div  class="name">{{ item.value=item.locationName }}</div>

</template>

</el-autocomplete>
````
# 解决方法
v-model="reqForm.robotSiteName" 绑定值robotSiteName未在data中未定义导致的问题，具体原理以后有时间研究
```
data() {

return {
  reqForm:{
            robotSiteName:''
          }
    }
}
```
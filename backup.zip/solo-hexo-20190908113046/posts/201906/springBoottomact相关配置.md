title: springBoot tomact相关配置
date: '2019-06-05 18:01:20'
updated: '2019-06-05 18:01:20'
tags: [java, springBoot]
permalink: /articles/2019/06/05/1559728880057.html
---
# 1、在application.yml配置contentPath
```
server:
  context-path: /XXXXXX
```

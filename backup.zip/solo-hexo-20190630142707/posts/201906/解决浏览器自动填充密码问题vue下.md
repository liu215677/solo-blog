title: 解决浏览器自动填充密码问题vue下
date: '2019-06-28 14:54:08'
updated: '2019-06-28 14:54:08'
tags: [vue]
permalink: /articles/2019/06/28/1561704848465.html
---
# 1、谷歌浏览器对type为password的 input会自动进行填充操作，如果想关闭自动填充可以试试下面的方法
设置input为只读可以有效防止填充，在获取焦点时触发事件把只读属性去除即可。
```
<el-input @focus="remoRead" :readonly="pwdReadOnly"  type="password"  v-model="form.newPassword"></el-input>
```
```
data() {
     return {
     pwdReadOnly:true,
```
```
remoRead(){

    this.pwdReadOnly=false;

}
```
好的大功告成。
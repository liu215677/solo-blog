title: linux部署mysql
date: '2019-05-25 14:22:44'
updated: '2019-05-25 14:47:36'
tags: [mysql]
permalink: /articles/2019/05/25/1558765363956.html
---
![安排.png](https://img.hacpai.com/file/2019/05/安排-62869e69.png)

## 1、下载
[https://dev.mysql.com/downloads/mysql/5.6.html#downloads](https://dev.mysql.com/downloads/mysql/5.6.html#downloads)
![image.png](https://img.hacpai.com/file/2019/05/image-f62164ab.png)
这里选择的是5.6.44版本
安装步骤
====
### 0、卸载老版本MySQL
查找并删除mysql有关的文件
```
`find / -name mysql rm -rf 上边查找到的路径，多个路径用空格隔开 #或者下边一条命令即可 find / -name mysql|xargs rm -rf`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-305617e34955e4d3.png?imageMogr2/auto-orient/strip%7CimageView2/2)
### 1、在安装包存放目录下执行命令解压文件：
```
`tar -zxvf mysql-5.6.31-linux-glibc2.5-x86_64.tar.gz`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-f8b6174388c8531d.png?imageMogr2/auto-orient/strip%7CimageView2/2)
### 2、删除安装包，重命名解压后的文件
```
`rm -f mysql-5.6.31-linux-glibc2.5-x86_64.tar.gz mv mysql-5.6.31-linux-glibc2.5-x86_64/ mysql`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-7c5b2ca42cf623e1.png?imageMogr2/auto-orient/strip%7CimageView2/2)
### 3、添加mysql用户组和mysql用户
先检查是否有mysql用户组和mysql用户
```
`groups mysql`
```

![null](https://upload-images.jianshu.io/upload_images/1899977-cc398fb960e0cb76.png?imageMogr2/auto-orient/strip%7CimageView2/2)
若无，则添加；
```
`groupadd mysql useradd -r -g mysql mysql`~~~~
```
![null](https://upload-images.jianshu.io/upload_images/1899977-f80edc428a9e61cf.png?imageMogr2/auto-orient/strip%7CimageView2/2)

若有，则跳过；
![null](https://upload-images.jianshu.io/upload_images/1899977-6aee55a3221c0446.png?imageMogr2/auto-orient/strip%7CimageView2/2)
### 4、进入mysql目录更改权限

```
`cd mysql/ chown -R mysql:mysql ./`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-ad018015ea413b53.png?imageMogr2/auto-orient/strip%7CimageView2/2)
### 5、执行安装脚本
```
`./scripts/mysql_install_db --user=mysql`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-e07b0b2383d9fc81.png?imageMogr2/auto-orient/strip%7CimageView2/2)
安装完之后修改当前目录拥有者为root用户，修改data目录拥有者为mysql
```
`chown -R root:root ./ chown -R mysql:mysql data`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-4e2b1c5c2fd75d24.png?imageMogr2/auto-orient/strip%7CimageView2/2)
### 6、更改mysql密码
上一步安装脚本执行输出的日志中告诉我们如何更改密码了

![null](https://upload-images.jianshu.io/upload_images/1899977-ccd379696682e6c6.png?imageMogr2/auto-orient/strip%7CimageView2/2)
但是如果直接执行这两条命令就会报错
![null](https://upload-images.jianshu.io/upload_images/1899977-151811b1ccfd6b75.png?imageMogr2/auto-orient/strip%7CimageView2/2)
因为这时还没有启动mysql，这算是一个坑。启动方法如下：
```
`./support-files/mysql.server start`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-31eacd5fca58b5b5.png?imageMogr2/auto-orient/strip%7CimageView2/2)
如果MySQL启动报错，则可能是已经存在MySQL进程，杀掉即可
```
`ps aux|grep mysql kill -9 上边的进程号 #或者下边一条命令即可杀掉所有MySQL进程 ps aux|grep mysql|awk '{print $2}'|xargs kill -9`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-6572db71fdf5faa7.png?imageMogr2/auto-orient/strip%7CimageView2/2)



杀掉后再启动即可。

![null](https://upload-images.jianshu.io/upload_images/1899977-f417bdc69058de74.png?imageMogr2/auto-orient/strip%7CimageView2/2)
MySQL启动之后再执行如下命令更改密码：
```
`./bin/mysqladmin -u root -h localhost.localdomain password 'root'`
```

![null](https://upload-images.jianshu.io/upload_images/1899977-d1a1c4478febf199.png?imageMogr2/auto-orient/strip%7CimageView2/2)
密码更改后即可登录MySQL
```
`./bin/mysql -h127.0.0.1 -uroot -proot`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-c22b674ff3f96009.png?imageMogr2/auto-orient/strip%7CimageView2/2)

登录之后将其他用户的密码也可改为root
```
`update mysql.user set password=password('root') where user='root'; flush privileges;`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-010a473ab72f59fc.png?imageMogr2/auto-orient/strip%7CimageView2/2)

7、增加远程登录权限
上一步即可本地登录，但远程登录会报错
![null](https://upload-images.jianshu.io/upload_images/1899977-2185d688960a5413.png?imageMogr2/auto-orient/strip%7CimageView2/2)
为解决这一问题，需要本地登陆MySQL后执行如下命令
```
`grant all privileges on *.* to root@'%' identified by 'root'; flush privileges;`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-8488efcf4d8d96a1.png?imageMogr2/auto-orient/strip%7CimageView2/2)

执行之后即可远程登录
![null](https://upload-images.jianshu.io/upload_images/1899977-45f2148fec4a53af.png?imageMogr2/auto-orient/strip%7CimageView2/2)
### 8、将MySQL加入Service系统服务
这个地方我没有成功，因为我安装之前已经加过服务了
```
`cp support-files/mysql.server /etc/init.d/mysqld chkconfig --add mysqld chkconfig mysqld on service mysqld restart  service mysqld status`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-e8c7c78c63097796.png?imageMogr2/auto-orient/strip%7CimageView2/2)
![null](https://upload-images.jianshu.io/upload_images/1899977-ba65cfbc31d07567.png?imageMogr2/auto-orient/strip%7CimageView2/2)
### 9、配置my.cnf
```
`vim my.cnf #添加以下两条语句并保存退出 character_set_server=utf8 lower_case_table_names=1 max_allowed_packet=100M`
```
![null](https://upload-images.jianshu.io/upload_images/1899977-d145484bd42a4b63.png?imageMogr2/auto-orient/strip%7CimageView2/2)
配置好之后，重启mysqld服务

![null](https://upload-images.jianshu.io/upload_images/1899977-c7178785535c5175.png?imageMogr2/auto-orient/strip%7CimageView2/2)

转载地址：https://www.cnblogs.com/wangdaijun/p/6132632.html


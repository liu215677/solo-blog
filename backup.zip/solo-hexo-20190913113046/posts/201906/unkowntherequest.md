title: unkown the request
date: '2019-06-17 17:02:48'
updated: '2019-06-17 17:02:48'
tags: [vue]
permalink: /articles/2019/06/17/1560762168436.html
---
问题unkown the request的原因是端口被占。解决端口占用问题：若8082端口被占用  
  
1、开始---->运行---->cmd，或者是window+R组合键（注意需要管理员身份运行），调出DOS命令窗口    
  
2_方法1、netstat -ano|findstr 8082   直接查看被占用端口8082，若此行的PID为8492  
  
3_方法1、taskkill /pid 8492 -t -f    杀死占用进程
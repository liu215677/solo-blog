title: 百度地图轨迹 vue 实现
date: '2019-06-27 17:44:34'
updated: '2019-06-27 17:48:08'
tags: [百度]
permalink: /articles/2019/06/27/1561628674346.html
---
# 1、index.html
找到index.html，引入百度api
```
<script  type="text/javascript"  src="http://api.map.baidu.com/api?v=3.0&ak=G0MphTEF4SObZhZrcyr2MhLA3izuwGHA"></script>
```
```
<!DOCTYPE  html>

<html>

<head>

<meta  charset="utf-8">

<meta  name="viewport"  content="width=device-width,initial-scale=1.0">

<title>learn-vue</title>
<!--引入百度api-->
<script  type="text/javascript"  src="http://api.map.baidu.com/api?v=3.0&ak=G0MphTEF4SObZhZrcyr2MhLA3izuwGHA"></script>

</head>

<body>

<div  id="app"></div>

<!-- built files will be auto injected -->

</body>

</html>
```
# 2、创建一个map.vue
```
<!-- -->

  

<template>

<div  style="height:100%">

<meta  name="viewport"  content="initial-scale=1.0, user-scalable=no">

<h1>hello 地图</h1>

<div  class="map"  id="container"></div>

</div>

</template>

  

<script>

export  default {

data() {

return {

map:  "",

city:  ""

};

},

mounted() {

this.city  =  "北京";

let  city  =  this.city;

this.map  =  new  BMap.Map("container"); // 百度地图API功能

this.map.centerAndZoom(city, 14); // 设置地图显示的城市和地图级别

this.map.enableScrollWheelZoom(); // 启用滚轮放大缩小，默认禁用

this.map.enableContinuousZoom(); // 启用地图惯性拖拽，默认禁用

this.map.addControl(new  BMap.NavigationControl()); // 添加默认缩放平移控件

this.map.addControl(new  BMap.ScaleControl()); // 添加比例尺控件

this.map.addControl(new  BMap.MapTypeControl()); // 添加地图类型控件

this.map.addControl(new  BMap.OverviewMapControl()); // 添加缩略地图控件

this.map.enableScrollWheelZoom(true);

//map.centerAndZoom(point, 15);

this.onCreate();

},

methods: {

onCreate() {

var  json  = [

{

status:  0,

message:  "成功",

total:  4,

size:  4,

distance:  602.06941225028,

toll_distance:  0,

start_point: {

longitude:  116.3804234005,

latitude:  39.9199022458,

loc_time:  1561506339

},

end_point: {

longitude:  116.380515,

latitude:  39.915179,

loc_time:  1561513839

},

points: [

{

loc_time:  1561506339,

latitude:  39.9199022458,

longitude:  116.3804234005,

create_time:  "2019-06-26 17:02:05",

speed:  7.224833,

direction:  255

},

{

loc_time:  1561506639,

latitude:  39.9185578186,

longitude:  116.3735818863,

create_time:  "2019-06-26 17:02:47",

speed:  2

},

{

loc_time:  1561510239,

latitude:  39.9071644301,

longitude:  116.3742792606,

create_time:  "2019-06-26 17:05:56",

speed:  2

},

{

loc_time:  1561513839,

latitude:  39.915179,

longitude:  116.380515,

create_time:  "2019-06-26 17:07:19",

speed:  1

}

]

}

];

var  result  = [

{

id:  "1",

address:  "1",

userid:  "a1",

latitude:  39.9199022458,

longitude:  116.3804234005,

datetime:  "2016"

},

{

id:  "4",

address:  "4",

userid:  "a4",

latitude:  39.915179,

longitude:  116.380515,

datetime:  "2016"

}

];

this.map.clearOverlays(); // 清除标注信息

var  points  = []; // 添加折线运动轨迹

var  i;

for (i  =  0; i  <  result.length; i++) {

var  userid  =  result[i].userid; // 用户ID

var  longitude  =  result[i].longitude; // 经度

var  latitude  =  result[i].latitude; // 纬度

var  address  =  result[i].address; // 地点

var  sign_time  =  result[i].datetime; // 签到时间

var  point  =  new  BMap.Point(longitude, latitude); // 填充标注点

let  city  =  this.city;

if (i  ==  0) {

city  =  result[i].address;

this.map.centerAndZoom(city, 14);

this.map.setCenter(point); // 设置中心坐标

}

var  tips  =  userid  +  "，"  +  sign_time  +  "，"  +  address;

this.addMarker(point, this.map, tips);

points.push(point);

}

var  polyline  =  new  BMap.Polyline(points);

this.map.addOverlay(polyline);

},

addMarker(point, map, tips) {

var  marker  =  new  BMap.Marker(point);

this.map.addOverlay(marker);

//为标注添加文字信息

var  label  =  new  BMap.Label(tips, { offset:  new  BMap.Size(20, -10) });

marker.setLabel(label);

}

}

};

</script>

<style  scoped>

.map {

width: 100%;

height: 500px;

}

</style>

```
效果图
![image.png](https://img.hacpai.com/file/2019/06/image-4b1bf405.png)


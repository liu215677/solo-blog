title: 'vscode中Git: host key verification failed的解决办法'
date: '2019-05-29 11:33:31'
updated: '2019-05-29 11:33:31'
tags: [vscode, git]
permalink: /articles/2019/05/29/1559100811592.html
---
在新仓库中使用tortoiseGit来clone、pull、push代码没有问题。但是，想使用vscode的git拓展的时候报错“Git: host key verification failed”。
该方法使用的是GitGui来自动添加仓库的known_hosts配置，具体步骤如下：

1.  在已克隆好的代码仓库，右键点击“Git Gui here”
2.  点击Git Gui工具栏“Remote”，点击“Fetch from > origin”
3.  弹出的对话框中输入“yes”，点击“ok”确定操作

至此已经完成了新仓库known_hosts的配置添加，可在`~/.ssh/known_hosts`文件中查看。

![image.png](https://img.hacpai.com/file/2019/05/image-b061859c.png)
然后去vscode中pull  成功了
链接：https://juejin.im/post/5cb93cb0e51d456e5d3dac34  
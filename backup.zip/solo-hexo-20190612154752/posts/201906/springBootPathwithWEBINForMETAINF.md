title: springBoot Path with "WEB-INF" or "META-INF"
date: '2019-06-10 11:14:14'
updated: '2019-06-10 11:14:14'
tags: [springBoot]
permalink: /articles/2019/06/10/1560136454641.html
---
这个错误是由于springboot没有默认配置jsp引起的
# 1、配置application
```  
 spring.mvc.view.prefix: /WEB-INF/jsp/
 spring.mvc.view.suffix: .jsp
```
# 2\需要在pom中引入
```
<dependency>
            <groupId>javax.servlet</groupId>
            <artifactId>jstl</artifactId>
        </dependency>
 
        <dependency>
            <groupId>org.apache.tomcat.embed</groupId>
            <artifactId>tomcat-embed-jasper</artifactId>
            <scope>provided</scope>
</dependency>
```
即可
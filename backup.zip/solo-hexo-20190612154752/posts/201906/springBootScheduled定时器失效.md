title: springBoot @Scheduled 定时器失效
date: '2019-06-10 11:31:06'
updated: '2019-06-10 11:31:24'
tags: [springBoot]
permalink: /articles/2019/06/10/1560137465984.html
---
加入@EnableScheduling注解
```
@EnableScheduling

@Controller
public class AppController```